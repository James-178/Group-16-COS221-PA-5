

<?php
// Database configuration
define('DB_SERVER', 'wheatley.cs.up.ac.za'); //server name
define('DB_USER', ''); //studentnumber
define('DB_PASSWORD', ''); //phpmyadmin password
define('DB_NAME', ''); //database name
?>